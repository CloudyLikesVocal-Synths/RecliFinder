import SwiftUI
import Foundation
import AVFoundation

// MARK: - PhonemeData
struct LanguagePhonemeSet: Identifiable, Codable {
    let id = UUID()
    let name: String // e.g., "Japanese", "English", "Korean", "X-SAMPA"
    let vowels: [String]
    let consonants: [String]
    let specialSounds: [String] // e.g., "N" for Japanese, glottal stops, specific Arpasing markers
    let diphthongs: [String]
    let clusters: [String]
}

struct PhonemeDataLoader {
    static func loadPhonemeData() -> [LanguagePhonemeSet] {
        // Generic placeholder phonemes for newly added languages
        let genericVowels = ["a", "e", "i", "o", "u"]
        let genericConsonants = ["p", "t", "k", "s", "m", "n", "l", "r"]

        var unsortedLanguages: [LanguagePhonemeSet] = [
            // MARK: African Languages
            LanguagePhonemeSet(
                name: "Afrikaans",
                vowels: ["a", "ə", "i", "ɪ", "o", "ɔ", "u", "ʊ", "y", "œ", "aː", "eə", "iə", "oə", "uə"],
                consonants: ["p", "b", "t", "d", "k", "g", "f", "v", "s", "z", "ʃ", "x", "ɦ", "m", "n", "ŋ", "l", "r"],
                specialSounds: [],
                diphthongs: ["aɪ", "œu", "oɪ", "ʌi"],
                clusters: ["bl", "br", "dr", "fl", "fr", "gl", "gr", "kl", "kr", "pl", "pr", "skr", "spl", "spr", "str"]
            ),
            LanguagePhonemeSet(
                name: "Amharic",
                vowels: ["ä", "u", "i", "a", "e", "ə", "o"], // 7 basic vowels
                consonants: ["p", "t", "c", "k", "b", "d", "ǧ", "g", "f", "s", "ʃ", "h", "z", "ʒ", "m", "n", "ɲ", "w", "l", "r", "j", "q", "ts", "dz", "ch"],
                specialSounds: ["p'", "t'", "c'", "k'", "s'", "ts'"], // Ejective consonants
                diphthongs: [],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Hausa",
                vowels: ["a", "e", "i", "o", "u", "aa", "ee", "ii", "oo", "uu"], // Short and long
                consonants: ["b", "d", "ɗ", "f", "g", "h", "j", "k", "ƙ", "l", "m", "n", "r", "s", "ʃ", "t", "ts", "w", "y", "z", "ʒ", "ʔ"],
                specialSounds: ["ɗ", "ƙ", "ts", "ʔ"], // Implosives, ejectives, glottal stop
                diphthongs: ["ai", "au"],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Igbo",
                vowels: ["a", "e", "i", "ɪ", "o", "ɔ", "u", "ʊ"], // 8 oral vowels
                consonants: ["p", "b", "t", "d", "k", "g", "f", "v", "s", "z", "ʃ", "m", "n", "ŋ", "l", "r", "w", "j", "kp", "gb", "nw", "ny"],
                specialSounds: ["kp", "gb", "nw", "ny"], // Labial-velar, nasal compounds
                diphthongs: [],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Lingala",
                vowels: ["a", "e", "ɛ", "i", "o", "ɔ", "u"], // 7 vowels
                consonants: ["p", "b", "t", "d", "k", "g", "f", "v", "s", "z", "ʃ", "h", "m", "n", "ŋ", "ɲ", "l", "r", "w", "j"],
                specialSounds: ["mb", "nd", "ng", "nz"], // Pre-nasalized consonants
                diphthongs: [],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Oromo",
                vowels: ["a", "e", "i", "o", "u", "aa", "ee", "ii", "oo", "uu"], // Short and long
                consonants: ["p", "b", "t", "d", "c", "j", "k", "g", "f", "s", "ʃ", "h", "m", "n", "ny", "l", "r", "w", "y", "ts", "d", "ch"],
                specialSounds: ["ph", "th", "ch", "dh", "kh"], // Ejectives
                diphthongs: [],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Somali",
                vowels: ["a", "e", "i", "o", "u", "aa", "ee", "ii", "oo", "uu"], // Short and long
                consonants: ["b", "t", "j", "x", "kh", "d", "r", "s", "sh", "dh", "c", "g", "f", "q", "k", "l", "m", "n", "w", "h", "y"],
                specialSounds: ["dh", "c", "q", "x"], // Retroflex, pharyngeal, uvular, glottal
                diphthongs: [],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Swahili",
                vowels: ["a", "e", "i", "o", "u"],
                consonants: ["b", "ch", "d", "dh", "f", "g", "gh", "h", "j", "k", "kh", "l", "m", "n", "ng", "ny", "p", "r", "s", "sh", "t", "th", "v", "w", "y", "z"],
                specialSounds: [],
                diphthongs: [],
                clusters: ["mb", "nd", "ng'", "nj"] // Common pre-nasalized stops
            ),
            LanguagePhonemeSet(
                name: "Yoruba",
                vowels: ["a", "e", "ɛ", "i", "o", "ɔ", "u"], // Includes open-mid vowels
                consonants: ["p", "b", "t", "d", "k", "g", "f", "s", "ʃ", "h", "m", "n", "ŋ", "l", "r", "w", "j"],
                specialSounds: ["kp", "gb"], // Labial-velar stops
                diphthongs: [],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Zulu",
                vowels: ["a", "e", "i", "o", "u"],
                consonants: ["p", "b", "t", "d", "k", "g", "f", "v", "s", "z", "ʃ", "h", "m", "n", "ŋ", "l", "r", "w", "j",
                             "c", "q", "x", // Clicks
                             "pc", "tq", "kx"], // Click variations (simplified)
                specialSounds: ["c", "q", "x"], // Clicks
                diphthongs: [],
                clusters: []
            ),

            // MARK: Asian Languages
            LanguagePhonemeSet(
                name: "Arabic",
                vowels: ["a", "i", "u", "ā", "ī", "ū"], // Short and long vowels
                consonants: ["b", "t", "th", "j", "ḥ", "kh", "d", "dh", "r", "z", "s", "sh", "ṣ", "ḍ", "ṭ", "ẓ", "ʿ", "gh", "f", "q", "k", "l", "m", "n", "h", "w", "y"], // Simplified Arabic consonants
                specialSounds: ["hamza"], // Alif (glottal stop)
                diphthongs: [],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Bengali",
                vowels: ["a", "ā", "i", "ī", "u", "ū", "e", "o", "ɔ", "æ"],
                consonants: ["k", "kh", "g", "gh", "ṅ", "c", "ch", "j", "jh", "ñ", "ṭ", "ṭh", "ḍ", "ḍh", "ṇ", "t", "th", "d", "dh", "n", "p", "ph", "b", "bh", "m", "y", "r", "l", "s", "h"], // Simplified
                specialSounds: [],
                diphthongs: [],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Chinese (Mandarin)",
                vowels: ["a", "o", "e", "i", "u", "ü", "ai", "ei", "ao", "ou", "an", "en", "ang", "eng", "er"],
                consonants: ["b", "p", "m", "f", "d", "t", "n", "l", "g", "k", "h", "j", "q", "x", "zh", "ch", "sh", "r", "z", "c", "s"],
                specialSounds: [],
                diphthongs: [],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Farsi",
                vowels: ["a", "æ", "e", "i", "o", "u"],
                consonants: ["p", "b", "t", "d", "k", "g", "f", "v", "s", "z", "ʃ", "ʒ", "x", "ɣ", "h", "m", "n", "l", "r", "j", "tʃ", "dʒ", "ʔ", "ʕ"],
                specialSounds: ["ʔ", "ʕ"],
                diphthongs: [],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Filipino (Tagalog)",
                vowels: ["a", "e", "i", "o", "u"],
                consonants: ["b", "k", "d", "g", "h", "l", "m", "n", "ng", "p", "r", "s", "t", "w", "y", "glottal"],
                specialSounds: ["glottal"], // Glottal stop is important
                diphthongs: [],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Gujarati",
                vowels: ["ə", "a", "i", "u", "e", "o", "ɛ", "ɔ", "ɪ", "ʊ", "ã", "ĩ", "ũ", "ẽ", "õ", "ɛ̃", "ɔ̃"],
                consonants: ["p", "b", "t", "d", "k", "g", "f", "v", "s", "z", "ʃ", "h", "m", "n", "ŋ", "l", "r", "ʋ", "j", "ts", "dz", "tʃ", "dʒ", "pʰ", "bʱ", "tʰ", "dʱ", "kʰ", "gʱ", "ʈ", "ɖ", "ɳ", "ɭ"],
                specialSounds: [],
                diphthongs: ["ai", "au"],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Hindi",
                vowels: ["a", "ā", "i", "ī", "u", "ū", "e", "ai", "o", "au"], // Short and long vowels
                consonants: ["k", "kh", "g", "gh", "ṅ", "c", "ch", "j", "jh", "ñ", "ṭ", "ṭh", "ḍ", "ḍh", "ṇ", "t", "th", "d", "dh", "n", "p", "ph", "b", "bh", "m", "y", "r", "l", "v", "ś", "ṣ", "s", "h"], // Simplified, includes aspirated and retroflex
                specialSounds: [],
                diphthongs: [],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Indonesian",
                vowels: ["a", "i", "u", "e", "o", "eu"],
                consonants: ["b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "r", "s", "t", "v", "w", "y", "z", "ng", "ny", "sy", "kh", "gh"],
                specialSounds: [],
                diphthongs: [],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Japanese",
                vowels: ["a", "i", "u", "e", "o"],
                consonants: ["k", "g", "s", "z", "t", "d", "n", "h", "b", "p", "m", "y", "r", "w", "ch", "ts", "sh", "j", "f", "ky", "gy", "shy", "jy", "chy", "ny", "hy", "by", "py", "my", "ry"], // Added palatalized
                specialSounds: ["N", "R", "br", "cl", "-"], // Moraic N, glottal/silent R, breath, glottal stop, long vowel/pause
                diphthongs: [], // Diphthongs are typically represented as vowel sequences in Japanese VOCALOID
                clusters: [] // Clusters are handled by compound consonants like 'ky'
            ),
            LanguagePhonemeSet(
                name: "Kannada",
                vowels: ["a", "aː", "i", "iː", "u", "uː", "e", "eː", "o", "oː"],
                consonants: ["p", "b", "t", "d", "k", "g", "s", "h", "m", "n", "ɲ", "ŋ", "l", "ɭ", "r", "ɾ", "v", "j", "ts", "dʒ", "ɖ", "ʈ", "ɳ", "ʂ", "ɕ", "tɕʰ", "dʑʱ", "c", "ɟ"],
                specialSounds: [],
                diphthongs: ["ai", "au"],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Korean",
                vowels: ["a", "eo", "o", "u", "i", "e", "ae", "ya", "yeo", "yo", "yu", "ye", "wa", "wae", "oe", "wo", "we", "wi", "ui"],
                consonants: ["b", "d", "g", "m", "s", "j", "ch", "p", "h", "k", "n", "l", "r", "ng", "ss", "jj", "tt", "kk", "pp"],
                specialSounds: [],
                diphthongs: [],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Marathi",
                vowels: ["ə", "a", "i", "u", "e", "o", "ɛ", "ɔ", "aː", "iː", "uː", "eː", "oː"],
                consonants: ["p", "b", "t", "d", "k", "g", "s", "h", "m", "n", "ɲ", "ŋ", "l", "ɭ", "r", "ʋ", "j", "tʃ", "dʒ", "pʰ", "bʱ", "tʰ", "dʱ", "kʰ", "gʱ", "ʈ", "ɖ", "ɳ", "ʂ", "ɕ", "z", "f"],
                specialSounds: [],
                diphthongs: [],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Punjabi",
                vowels: ["ɪ", "ʊ", "ə", "i", "e", "ɛ", "u", "a", "o", "ɔ", "ɪ̃", "ʊ̃", "ə̃", "ĩ", "ẽ", "ɛ̃", "ũ", "ã", "õ", "ɔ̃"],
                consonants: ["p", "b", "t", "d", "k", "g", "s", "h", "m", "n", "ɲ", "ŋ", "l", "ɭ", "r", "ɾ", "ʋ", "j", "tʃ", "dʒ", "ʈ", "ɖ", "ʂ", "ɕ", "f", "z"],
                specialSounds: ["ɦ"],
                diphthongs: [],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Tamil",
                vowels: ["a", "aa", "i", "ii", "u", "uu", "e", "ee", "ai", "o", "oo", "au"],
                consonants: ["k", "ng", "s", "nj", "t", "nt", "th", "n", "p", "m", "y", "r", "l", "v", "zh", "l̥", "n"],
                specialSounds: ["ஃ"],
                diphthongs: ["ai", "au"],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Telugu",
                vowels: ["a", "aː", "i", "iː", "u", "uː", "e", "eː", "o", "oː", "ʉ", "æː"],
                consonants: ["p", "b", "t", "d", "k", "g", "s", "h", "m", "n", "ŋ", "j", "l", "pʰ", "tʰ", "ʈʰ", "cʰ", "kʰ", "ʈ", "ɖ", "ɳ", "ɭ", "c", "ɟ", "ɾ", "bʱ", "dʱ", "ɖʱ", "ɟʱ", "ɡʱ"],
                specialSounds: [],
                diphthongs: ["ai", "au"],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Thai",
                vowels: ["a", "i", "u", "e", "o", "ae", "o", "oe", "ia", "ua", "eu", "uu"], // Simplified Thai vowels
                consonants: ["k", "kh", "g", "ng", "c", "ch", "j", "t", "th", "d", "n", "p", "ph", "b", "m", "y", "r", "l", "w", "s", "h"], // Simplified Thai consonants
                specialSounds: [], // Thai has complex tones, aspiration, and final consonants
                diphthongs: [],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Vietnamese",
                vowels: ["a", "ă", "â", "e", "ê", "i", "o", "ô", "ơ", "u", "ư", "y"],
                consonants: ["b", "c", "d", "đ", "g", "h", "k", "l", "m", "n", "p", "q", "r", "s", "t", "v", "x"],
                specialSounds: [], // Vietnamese has complex tones and initial/final consonants
                diphthongs: [],
                clusters: []
            ),

            // MARK: European Languages
            LanguagePhonemeSet(
                name: "Czech",
                vowels: ["a", "e", "i", "o", "u", "y", "á", "é", "í", "ó", "ú", "ý"],
                consonants: ["b", "c", "č", "d", "ď", "f", "g", "h", "ch", "j", "k", "l", "m", "n", "ň", "p", "r", "ř", "s", "š", "t", "ť", "v", "z", "ž"],
                specialSounds: ["r̝"],
                diphthongs: ["ou", "au", "eu"],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Danish",
                vowels: ["a", "e", "i", "o", "u", "y", "æ", "ø", "å"],
                consonants: ["p", "b", "t", "d", "k", "g", "f", "v", "s", "z", "ʃ", "h", "m", "n", "ŋ", "l", "r", "ð"],
                specialSounds: ["r"], // Soft D and uvular R
                diphthongs: [],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Dutch",
                vowels: ["a", "ɑ", "e", "ɛ", "i", "ɪ", "o", "ɔ", "u", "ʏ", "ø", "œ", "aɪ", "aʊ", "œʏ"],
                consonants: ["p", "b", "t", "d", "k", "g", "f", "v", "s", "z", "ʃ", "ʒ", "x", "ɣ", "h", "m", "n", "ŋ", "l", "r", "ʋ", "j", "ts"],
                specialSounds: [],
                diphthongs: ["aɪ", "aʊ", "œʏ"],
                clusters: ["bl", "br", "dr", "fl", "fr", "gl", "gr", "kl", "kr", "pl", "pr", "sch", "skl", "skr", "sp", "spl", "spr", "st", "str", "sv"]
            ),
            LanguagePhonemeSet(
                name: "English",
                vowels: ["aa", "ae", "ah", "eh", "er", "ih", "iy", "oh", "oo", "uh", "uw"], // Simplified English vowels
                consonants: ["b", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "r", "s", "t", "v", "w", "y", "z", "sh", "ch", "th", "dh", "zh", "ng"], // Simplified English consonants
                specialSounds: [],
                diphthongs: ["ay", "oy", "ow"], // Common diphthongs
                clusters: ["bl", "br", "cl", "cr", "dr", "fl", "fr", "gl", "gr", "pl", "pr", "sc", "sk", "sl", "sm", "sn", "sp", "st", "sw", "tr", "tw", "thr", "shr"] // Common English clusters
            ),
            LanguagePhonemeSet(
                name: "Finnish",
                vowels: ["a", "e", "i", "o", "u", "y", "æ", "ø"],
                consonants: ["p", "t", "k", "d", "s", "h", "m", "n", "ŋ", "l", "r", "v", "j"],
                specialSounds: [],
                diphthongs: ["ai", "ei", "oi", "ui", "yi", "æi", "øi", "au", "eu", "ou", "iu", "iy", "ey", "äy", "öy"],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "French",
                vowels: ["a", "ɑ", "e", "ə", "ɛ", "i", "o", "ɔ", "u", "y", "ø", "œ", "ɑ̃", "ɛ̃", "ɔ̃", "œ̃"],
                consonants: ["p", "b", "t", "d", "k", "g", "f", "v", "s", "z", "ʃ", "ʒ", "l", "ʀ", "m", "n", "ɲ", "w", "ɥ", "j"],
                specialSounds: [],
                diphthongs: [],
                clusters: ["bl", "br", "cl", "cr", "dr", "fl", "fr", "gl", "gr", "pl", "pr", "tr", "vr"]
            ),
            LanguagePhonemeSet(
                name: "German",
                vowels: ["a", "e", "i", "o", "u", "ä", "ö", "ü", "ai", "au", "eu"],
                consonants: ["p", "b", "t", "d", "k", "g", "f", "v", "s", "z", "ʃ", "ʒ", "ç", "x", "h", "m", "n", "ŋ", "l", "r", "ʁ", "j", "pf", "ts", "kv"],
                specialSounds: [],
                diphthongs: ["ai", "au", "eu"],
                clusters: ["bl", "br", "dr", "fl", "fr", "gl", "gr", "kl", "kr", "pf", "pl", "pr", "qu", "sch", "sp", "st", "str", "spr", "ts", "tr"]
            ),
            LanguagePhonemeSet(
                name: "Greek",
                vowels: ["a", "e", "i", "o", "u"],
                consonants: ["p", "b", "t", "d", "k", "g", "f", "θ", "ð", "s", "z", "ç", "ʝ", "x", "ɣ", "m", "n", "ɲ", "l", "ʎ", "r"],
                specialSounds: [],
                diphthongs: [],
                clusters: ["vr", "vl", "fr", "fl", "thr", "thl", "dhr", "dhl", "xth", "xpr", "xpl", "xtr", "xdr", "xkr", "xgr"]
            ),
            LanguagePhonemeSet(
                name: "Hebrew",
                vowels: ["a", "e", "i", "o", "u", "ɛ", "ɔ"],
                consonants: ["p", "b", "t", "d", "k", "g", "f", "v", "s", "z", "ʃ", "χ", "ɣ", "ħ", "ʕ", "h", "m", "n", "l", "r", "w", "j", "ʔ", "ts"],
                specialSounds: ["χ", "ʕ", "ʔ"],
                diphthongs: [],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Hungarian",
                vowels: ["a", "á", "e", "é", "i", "í", "o", "ó", "ö", "ő", "u", "ú", "ü", "ű"],
                consonants: ["p", "b", "t", "d", "k", "g", "f", "v", "s", "z", "ʃ", "ʒ", "h", "m", "n", "ɲ", "l", "r", "c", "tʃ", "dʒ", "dz", "ts", "ɟ"],
                specialSounds: [],
                diphthongs: [],
                clusters: ["cs", "dz", "dzs", "gy", "ly", "ny", "sz", "ty", "zs"]
            ),
            LanguagePhonemeSet(
                name: "Italian",
                vowels: ["a", "e", "ɛ", "i", "o", "ɔ", "u"],
                consonants: ["p", "b", "t", "d", "k", "g", "f", "v", "s", "z", "ʃ", "ts", "dz", "m", "n", "ɲ", "l", "ʎ", "r", "j", "w"],
                specialSounds: [],
                diphthongs: ["ai", "au", "ei", "eu", "ia", "ie", "io", "iu", "oi", "ou", "ua", "ue", "ui", "uo"],
                clusters: ["bl", "br", "cl", "cr", "dr", "fl", "fr", "gl", "gr", "pl", "pr", "tr"]
            ),
            LanguagePhonemeSet(
                name: "Norwegian",
                vowels: ["a", "e", "i", "o", "u", "y", "æ", "ø", "å"],
                consonants: ["p", "b", "t", "d", "k", "g", "f", "v", "s", "ʃ", "ç", "h", "m", "n", "ŋ", "l", "ɾ", "r", "j"],
                specialSounds: [],
                diphthongs: [],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Polish",
                vowels: ["a", "ɛ", "i", "ɔ", "u", "ɨ", "ɛ̃", "ɔ̃"], // Nasal vowels
                consonants: ["p", "b", "t", "d", "k", "g", "f", "v", "s", "z", "ʂ", "ʐ", "ɕ", "ʑ", "x", "m", "n", "ɲ", "l", "w", "j", "ts", "tɕ", "dʑ", "dz", "dʑ"],
                specialSounds: ["rj"], // Palatalized R (simplified)
                diphthongs: [],
                clusters: ["bź", "br", "chrz", "czł", "drz", "grz", "kr", "ksz", "mdl", "mkn", "mstw", "ndz", "pst", "rcz", "rdz", "rzg", "skrz", "sp", "st", "szcz", "trz", "wzg"] // Very common and complex clusters
            ),
            LanguagePhonemeSet(
                name: "Portuguese",
                vowels: ["a", "ɐ", "e", "ɛ", "i", "o", "ɔ", "u", "ɐ̃", "ẽ", "ĩ", "õ", "ũ"], // Includes nasal vowels
                consonants: ["p", "b", "t", "d", "k", "g", "f", "v", "s", "z", "ʃ", "ʒ", "m", "n", "ɲ", "l", "ʎ", "ɾ", "ʁ", "w", "j"],
                specialSounds: [],
                diphthongs: ["ai", "au", "ei", "eu", "iu", "oi", "ou", "ui"],
                clusters: ["bl", "br", "cl", "cr", "dr", "fl", "fr", "gl", "gr", "pl", "pr", "tr", "vr"]
            ),
            LanguagePhonemeSet(
                name: "Russian",
                vowels: ["a", "e", "i", "o", "u", "ɨ"], // Hard and soft vowels
                consonants: ["p", "b", "t", "d", "k", "g", "f", "v", "s", "z", "ʂ", "ʐ", "ɕ", "ʑ", "x", "m", "n", "l", "r", "j", "ts", "tɕ", "dʑ"],
                specialSounds: [], // Soft/palatalized consonants are key but simplified here
                diphthongs: [],
                clusters: ["bl", "br", "dv", "gl", "gr", "kv", "kr", "ml", "mr", "pl", "pr", "sl", "sm", "sn", "sp", "st", "sv", "tr", "vz", "zl", "zm", "zn"]
            ),
            LanguagePhonemeSet(
                name: "Spanish",
                vowels: ["a", "e", "i", "o", "u"],
                consonants: ["p", "b", "t", "d", "k", "g", "f", "θ", "s", "x", "m", "n", "ɲ", "l", "ʎ", "r", "ɾ", "ʝ", "w"],
                specialSounds: ["ɾɾ"], // Trilled R
                diphthongs: ["ai", "au", "ei", "eu", "ia", "ie", "io", "iu", "oi", "ou", "ua", "ue", "ui", "uo"],
                clusters: ["bl", "br", "cl", "cr", "dr", "fl", "fr", "gl", "gr", "pl", "pr", "tr"]
            ),
            LanguagePhonemeSet(
                name: "Swedish",
                vowels: ["a", "ɑː", "e", "ɛ", "ɪ", "iː", "ɔ", "oː", "ɵ", "uː", "ʏ", "yː", "æ", "ø", "ʷɔ", "ɵ"],
                consonants: ["p", "b", "t", "d", "k", "g", "f", "v", "s", "ɕ", "h", "m", "n", "ŋ", "l", "ɾ", "r", "j", "ɧ"],
                specialSounds: [],
                diphthongs: [],
                clusters: ["bl", "br", "dr", "fl", "fr", "gl", "gr", "kl", "kr", "pl", "pr", "sk", "sl", "sm", "sn", "sp", "st", "sv", "tr", "vr"]
            ),
            LanguagePhonemeSet(
                name: "Turkish",
                vowels: ["a", "e", "ı", "i", "o", "ö", "u", "ü"],
                consonants: ["p", "b", "t", "d", "k", "g", "f", "v", "s", "z", "ʃ", "ʒ", "h", "m", "n", "l", "r", "j", "ç", "c"],
                specialSounds: [],
                diphthongs: [],
                clusters: []
            ),
            LanguagePhonemeSet(
                name: "Ukrainian",
                vowels: ["ɑ", "ɛ", "ɪ", "i", "ɔ", "u"],
                consonants: ["p", "b", "t", "d", "k", "g", "f", "v", "s", "z", "ʃ", "ʒ", "x", "ɦ", "m", "n", "l", "r", "j", "tʃ", "dʒ", "ts", "dz", "ɲ", "ʎ", "rʲ"],
                specialSounds: [],
                diphthongs: [],
                clusters: [],
            ),
            ]


        // Ensure unique languages and sort them alphabetically by name
        var uniqueLanguages = [String: LanguagePhonemeSet]()
        for lang in unsortedLanguages {
            uniqueLanguages[lang.name] = lang
        }

        return uniqueLanguages.values.sorted { $0.name < $1.name }
    }
}

// MARK: - ReclistGenerator
struct ReclistGenerator {
    let phonemeData: [LanguagePhonemeSet]

    func getLanguagePhonemes(language: String) -> LanguagePhonemeSet? {
        return phonemeData.first(where: { $0.name == language })
    }

    func generateMultiMoraEntry(units: [String], moraCount: Int, separator: String) -> String {
        guard !units.isEmpty else { return "" }
        var entry = ""
        for i in 0..<moraCount {
            if let randomUnit = units.randomElement() {
                entry += randomUnit
                if i < moraCount - 1 {
                    entry += separator
                }
            }
        }
        return entry
    }

    func generateReclist(language: String, reclistType: String, moraCount: Int) -> String {
        guard let langSet = getLanguagePhonemes(language: language) else {
            return "Language phoneme data not found."
        }

        var reclist: [String] = []
        var generatedUniqueEntries: Set<String> = []
        let desiredNumEntries = 4500
        let maxAttempts = desiredNumEntries * 5

        var baseUnits: [String] = []

        switch reclistType {
        case "CV":
            baseUnits = langSet.consonants.flatMap { consonant in
                langSet.vowels.map { vowel in
                    consonant + vowel
                }
            } + langSet.consonants.flatMap { consonant in
                langSet.diphthongs.map { diphthong in
                    consonant + diphthong
                }
            }
        case "VCV":
            baseUnits = langSet.vowels.flatMap { v1 in
                langSet.consonants.flatMap { c in
                    langSet.vowels.map { v2 in
                        v1 + c + v2
                    }
                }
            }
        case "CVC":
            baseUnits = langSet.consonants.flatMap { c1 in
                langSet.vowels.flatMap { v in
                    langSet.consonants.map { c2 in
                        c1 + v + c2
                    }
                }
            }
        case "Vowel":
            baseUnits = langSet.vowels + langSet.diphthongs
        case "Consonant":
            baseUnits = langSet.consonants + langSet.clusters
        case "Arpasing":
            baseUnits = langSet.vowels + langSet.consonants + langSet.diphthongs + langSet.specialSounds
        case "X-SAMPA", "Synthesizer V", "VOCALOID": // VOCALOID now uses selected language's phonemes
            baseUnits = langSet.vowels + langSet.consonants + langSet.specialSounds + langSet.diphthongs + langSet.clusters
        case "VCCV":
            baseUnits = langSet.vowels.flatMap { v1 in
                langSet.consonants.flatMap { c1 in
                    langSet.consonants.flatMap { c2 in
                        langSet.vowels.map { v2 in
                            v1 + c1 + c2 + v2
                        }
                    }
                }
            }
        case "C+V":
            baseUnits = langSet.consonants.flatMap { c in langSet.vowels.map { v in c + "+" + v } }
        case "CCV":
            baseUnits = langSet.clusters.flatMap { cluster in
                langSet.vowels.map { vowel in
                    cluster + vowel
                }
            } + langSet.consonants.flatMap { c1 in
                langSet.consonants.flatMap { c2 in
                    langSet.vowels.map { v in
                        c1 + c2 + v
                    }
                }
            }
        case "CVVC":
            baseUnits = langSet.consonants.flatMap { c1 in
                langSet.vowels.flatMap { v1 in
                    langSet.vowels.flatMap { v2 in
                        langSet.consonants.map { c2 in
                            c1 + v1 + v2 + c2
                        }
                    }
                }
            }
        case "Custom":
            break
        default:
            return "Unsupported reclist type."
        }

        var attempts = 0
        while generatedUniqueEntries.count < desiredNumEntries && attempts < maxAttempts {
            var newEntry: String = ""

            let separator: String
            if reclistType == "Arpasing" || reclistType == "X-SAMPA" || reclistType == "Synthesizer V" || reclistType == "VOCALOID" {
                separator = " "
            } else {
                separator = "-"
            }

            switch reclistType {
            case "CV", "VCV", "CVC", "Vowel", "Consonant", "Arpasing", "X-SAMPA", "Synthesizer V", "VCCV", "C+V", "CCV", "CVVC", "VOCALOID":
                newEntry = generateMultiMoraEntry(units: baseUnits, moraCount: moraCount, separator: separator)
            case "VC_CVC":
                let vcUnits = langSet.vowels.flatMap { v in langSet.consonants.map { c in v + c } }
                let cvcUnits = langSet.consonants.flatMap { c1 in langSet.vowels.flatMap { v in langSet.consonants.map { c2 in c1 + v + c2 } } }
                if let vc = vcUnits.randomElement(), let cvc = cvcUnits.randomElement() {
                    newEntry = vc + "_" + cvc
                }
            case "CV_CVC":
                let cvUnits = langSet.consonants.flatMap { c in langSet.vowels.map { v in c + v } }
                let cvcUnits = langSet.consonants.flatMap { c1 in langSet.vowels.flatMap { v in langSet.consonants.map { c2 in c1 + v + c2 } } }
                if let cv = cvUnits.randomElement(), let cvc = cvcUnits.randomElement() {
                    newEntry = cv + "_" + cvc
                }
            case "Custom":
                newEntry = "Custom reclist generation not implemented yet."
            default:
                break
            }

            if !newEntry.isEmpty && !generatedUniqueEntries.contains(newEntry) {
                generatedUniqueEntries.insert(newEntry)
                reclist.append(newEntry)
            }
            attempts += 1
        }

        return reclist.joined(separator: "\n")
    }
}

// MARK: - ContentView
struct ContentView: View {
    @State private var selectedLanguage: String = "Japanese"
    @State private var selectedReclistType: String = "CV"
    @State private var moraCount: Int = 1 // Default to 1 mora
    @State private var generatedOutput: String = ""

    let reclistTypes = ["CV", "VCV", "CVC", "Vowel", "Consonant", "Arpasing", "X-SAMPA", "Synthesizer V", "Custom", "VCCV", "C+V", "CCV", "VC_CVC", "CV_CVC", "CVVC", "VOCALOID"]

    // Initialize ReclistGenerator with loaded phoneme data
    private let reclistGenerator = ReclistGenerator(phonemeData: PhonemeDataLoader.loadPhonemeData())

    var body: some View {
        ZStack {
            // Background with a subtle gradient or color
            LinearGradient(gradient: Gradient(colors: [Color.purple.opacity(0.2), Color.blue.opacity(0.2)]), startPoint: .topLeading, endPoint: .bottomTrailing)
                .edgesIgnoringSafeArea(.all)

            VStack(spacing: 20) {
                Text("RecliFinder's reclist Search Engine")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)

                // MARK: - Language Selection
                VStack(alignment: .leading) {
                    Text("Select Language:")
                        .font(.headline)
                    Picker("Select Language", selection: $selectedLanguage) {
                        ForEach(reclistGenerator.phonemeData) { lang in
                            Text(lang.name).tag(lang.name)
                        }
                    }
                    .pickerStyle(.menu)
                    .background(Color.white.opacity(0.8))
                    .cornerRadius(8)
                    .padding(.horizontal)
                }
                .padding(.horizontal)

                // MARK: - Reclist Type Selection
                VStack(alignment: .leading) {
                    Text("Select Reclist Type:")
                        .font(.headline)
                    Picker("Select Reclist Type", selection: $selectedReclistType) {
                        ForEach(reclistTypes, id: \.self) { type in
                            Text(type).tag(type)
                        }
                    }
                    .pickerStyle(.menu)
                    .background(Color.white.opacity(0.8))
                    .cornerRadius(8)
                    .padding(.horizontal)
                }
                .padding(.horizontal)

                // MARK: - Mora Count Selection (Always visible)
                VStack(alignment: .leading) {
                    Text("Moras:")
                        .font(.headline)
                    Picker("Mora Count", selection: $moraCount) {
                        ForEach(1..<11) { i in // Moras from 1 to 10
                            Text("\(i)").tag(i)
                        }
                    }
                    .pickerStyle(.segmented)
                    .background(Color.white.opacity(0.8))
                    .cornerRadius(8)
                    .padding(.horizontal)
                }
                .padding(.horizontal)


                Button("Search for a Reclist") {
                    generatedOutput = reclistGenerator.generateReclist(language: selectedLanguage, reclistType: selectedReclistType, moraCount: moraCount)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .padding(.horizontal)

                Divider()

                // MARK: - Generated Output
                VStack(alignment: .leading) {
                    Text("Generated Reclist (You can click Search for a Reclist again to find a new one.):")
                        .font(.headline)
                    ScrollView {
                        Text(generatedOutput)
                            .font(.body)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding()
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(5)
                            .textSelection(.enabled) // Allow copying
                    }
                    .frame(minHeight: 150, maxHeight: .infinity)
                }
                .padding(.horizontal)

                Spacer()
            }
            .padding()
            .frame(minWidth: 500, minHeight: 700)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
